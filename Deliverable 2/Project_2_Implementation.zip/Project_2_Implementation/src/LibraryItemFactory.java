
public abstract class LibraryItemFactory {
	public abstract Item createItem(String itemType);

}
