
public class Book extends Item {

	// Constructor
    public Book(int itemId, String title, String location, boolean available) {
    	super(itemId, title, location, available);
    }
    
    public Book() {
    	
    }
}
