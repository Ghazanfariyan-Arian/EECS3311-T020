package com.eecs3311.YorkULibraryManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YorkULibraryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(YorkULibraryManagementApplication.class, args);
	}

}
