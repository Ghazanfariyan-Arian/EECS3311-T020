package com.eecs3311.YorkULibraryManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YorkULibraryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
