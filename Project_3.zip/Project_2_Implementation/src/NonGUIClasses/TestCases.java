package NonGUIClasses;

import static org.junit.Assert.*;

import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class TestCases {
	 
	private ClientManager clientManager;

	private CSVWriter csvWriter;
	
	/*
	 * Client Test
	 */
	@Test
    public void testConstructorClient() {
        Client client = new Client(1, "test@example.com", "testpassword", "Student");
        assertEquals(1, client.getId());
        assertEquals("test@example.com", client.getEmail());
        assertEquals("testpassword", client.getPassword());
        assertEquals("Student", client.getType());

	}
	
	@Test
    public void testDefaultClient() {
        Client expectedDefaultClient = new Client();
        assertEquals(0, expectedDefaultClient.getId());
        assertEquals("default@example.com", expectedDefaultClient.getEmail());
        assertEquals("password", expectedDefaultClient.getPassword());
        assertEquals("Student", expectedDefaultClient.getType());
        assertNotNull(expectedDefaultClient.getCourses());
        
	}
	@Test
	public void testGettersAndSettersClient() {
	    Client client = new Client();
	    client.setId(1);
	    client.setEmail("test@example.com");
	    client.setPassword("testpassword");
	    client.setType("Student");
	    
	    assertEquals(1, client.getId());
	    assertEquals("test@example.com", client.getEmail());
	    assertEquals("testpassword", client.getPassword());
	    assertEquals("Student", client.getType());
	    }
	
	/*
	 * Student Test
	 */

	@Test
	public void testConstructorWithParamStudent() {
		Student student = new Student(1, "test@example.com", "testpassword", "Student");

		assertEquals(1, student.getId());
		assertEquals("test@example.com", student.getEmail());
		assertEquals("testpassword", student.getPassword());
		assertEquals("Student", student.getType());

		assertNotNull(student.getCourses());
		assertTrue(student.getCourses().isEmpty());
	}

	public void testAddCoursec() {
		Student student = new Student(1, "test@example.com", "testpassword", "Student");
		student.addCourse("Math", "2022");
		student.addCourse("Science", "2023");

		List<String> courses = student.getCourses();

		assertNotNull(courses);
		assertFalse(courses.isEmpty());
		assertEquals(2, courses.size());
		assertTrue(courses.contains("Math (Edition: 2022)"));
		assertTrue(courses.contains("Science (Edition: 2023)"));
	}

	@Test
	public void testRemoveCourse() {
		Student student = new Student(1, "test@example.com", "testpassword", "Student");
		student.addCourse("Math", "2022");
		student.addCourse("Science", "2023");
		student.removeCourse("Math (Edition: 2022)");

		List<String> expectedCourses = new ArrayList<>();
		expectedCourses.add("Science (Edition: 2023)");

		assertEquals(expectedCourses, student.getCourses());
	}
	@Test
    public void testConstructor3ParamStudent() {
		Student student = new Student(1, "test@example.com", "testpassword");

		assertEquals(1, student.getId());
        assertEquals("test@example.com", student.getEmail());
        assertEquals("testpassword", student.getPassword());
        assertEquals("Student", student.getType());

        assertNotNull(student.getCourses());
        assertTrue(student.getCourses().isEmpty());
    }
	
	/*
	 * Faculty Test
	 */
	  @Test
	    public void testConstructorWithParametersFaculty() {
	        // Testing constructor with parameters
	        Faculty faculty = new Faculty(1, "test@example.com", "testpassword", "Faculty");
	        assertEquals(1, faculty.getId());
	        assertEquals("test@example.com", faculty.getEmail());
	        assertEquals("testpassword", faculty.getPassword());
	        assertEquals("Faculty", faculty.getType());
	        assertNotNull(faculty.getCourses());
	        assertTrue(faculty.getCourses().isEmpty());
	    }
	  @Test
	    public void testAddCourseFaculty() {
	        // Testing addCourse method
	        Faculty faculty = new Faculty(1, "test@example.com", "testpassword", "Faculty");
	        faculty.addCourse("Computer Science", "2022");
	        faculty.addCourse("Mathematics", "2023");
	        
	        List<String> expectedCourses = new ArrayList<>();
	        expectedCourses.add("Computer Science (Edition: 2022)");
	        expectedCourses.add("Mathematics (Edition: 2023)");
	        
	        assertEquals(expectedCourses, faculty.getCourses());
	    }
	    
	    @Test
	    public void testRemoveCourseFaculty() {
	        // Testing removeCourse method
	        Faculty faculty = new Faculty(1, "test@example.com", "testpassword", "Faculty");
	        faculty.addCourse("Computer Science", "2022");
	        faculty.addCourse("Mathematics", "2023");
	        faculty.removeCourse("Computer Science (Edition: 2022)");
	        
	        List<String> expectedCourses = new ArrayList<>();
	        expectedCourses.add("Mathematics (Edition: 2023)");
	        
	        assertEquals(expectedCourses, faculty.getCourses());
	    }
	    
	    /*
	     * Item Test
	     */
	    @Test
	    public void testConstructorAndGettersItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        assertEquals(1, item.getItemId());
	        assertEquals("Book", item.getTitle());
	        assertEquals("Library", item.getLocations());
	        assertTrue(item.getAvailability());
	    }
	    @Test
	    public void testSettersItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        item.setItemId(2);
	        item.setTitle("Magazine");
	        item.setLocation("O");
	        item.setAvailability(false);
	        
	        assertEquals(2, item.getItemId());
	        assertEquals("Magazine", item.getTitle());
	        assertEquals("O", item.getLocations());
	        assertFalse(item.getAvailability());
	    }
	    @Test
	    public void testDetailsItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        String expectedDetails = "Item ID: 1\nTitle: Book\nLocation: Library\nAvailable: Yes";
	        assertEquals(expectedDetails, item.getItemDetails());
	       
	    }

	    @Test
	    public void testBorrowItem() {
	        Client client = new Client(1, "test@example.com", "testpassword", "Student");
	        Item item = new Item(1, "Book", "Library", true);
	        item.borrowItem(client);
	        assertFalse(item.getAvailability());
	    }
	    @Test
	    public void testReturnItem() {
	        Client client = new Client(1, "test@example.com", "testpassword", "Student");
	        Item item = new Item(1, "Book", "Library", false);
	        item.returnItem(client);
	        assertTrue(item.getAvailability());
	    }
	    @Test
	    public void testToStringItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        String expectedString = "ID: 1, Title: Book, Location: Library, Available: true";
	        assertEquals(expectedString, item.toString());
	    }
	    @Test
	    public void testSetAndGetBorrowDateItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        Date borrowDate = new Date();
	        item.setBorrowDate(borrowDate);
	        assertEquals(borrowDate, item.getBorrowDates());
	    }
	    @Test
	    public void testSetAndGetFormattedDueDateItem() {
	        Item item = new Item(1, "Book", "Library", true);
	        Calendar calendar = Calendar.getInstance();
	        Date borrowDate = new Date();
	        calendar.setTime(borrowDate);
	        item.setFormattedDueDate(borrowDate);

	        
	        Calendar exCalendar = Calendar.getInstance();
	        exCalendar.setTime(borrowDate);
	        exCalendar.add(Calendar.DAY_OF_MONTH, 30);
	        Date exdueDate = exCalendar.getTime();

	        SimpleDateFormat dateFormat = new SimpleDateFormat("E, MMM dd, yyyy");
	        String exFormattedDueDate = dateFormat.format(exdueDate);
	        
	
	        assertEquals(exFormattedDueDate, item.getFormattedDueDate());
	      
	    }
	    @Test
	    public void testGetBorrowDate() {
	        Date date = new Date(); 
	        Item item = new Item(1, "Test Item", "Library", true);
	        item.setBorrowDate(date);
	        assertEquals(date, item.getBorrowDates()); 
	    }
	    
	    /*
	     * Book Test
	     */
	    
	    @Test
	    public void testConstructorBook() {
	        int itemId = 1;
	        String title = "Test Book";
	        String location = "Library";
	        boolean available = true;
	        
	        Book book = new Book(itemId, title, location, available);
	        
	        assertEquals(itemId, book.getItemId());
	        assertEquals(title, book.getTitle());
	        assertEquals(location, book.getLocations());
	        assertEquals(available, book.getAvailability());
	    }
	    
	    /*
	     * CD Test
	     */
	    @Test
	    public void testConstructorCD() {
	        int itemId = 1;
	        String title = "CD Title";
	        String location = "CD Location";
	        boolean available = true;

	        CD cd = new CD(itemId, title, location, available);

	        assertEquals(itemId, cd.getItemId());
	        assertEquals(title, cd.getTitle());
	        assertEquals(location, cd.getLocations());
	        assertEquals(available, cd.getAvailability());
	    }
	    
	    /*
	     * Magazine Test
	     */
	    @Test
	    public void testMagazineConstructorWithParameters() {
	        int itemId = 1;
	        String title = "Magazine Title";
	        String location = "Magazine Location";
	        boolean available = true;

	        Magazine magazine = new Magazine(itemId, title, location, available);

	        assertEquals(itemId, magazine.getItemId());
	        assertEquals(title, magazine.getTitle());
	        assertEquals(location, magazine.getLocations());
	        assertEquals(available, magazine.getAvailability());

	    }
	    
	    /*
	     * Library Item Factory Test 
	     */

	    @Test
	    public void testCreateItem_Book() {
	        LibraryItemFactory factory = new ConcreteLibraryItemFactory();
	        Item book = factory.createItem("Book");
	        assertNotNull(book);
	        assertTrue(book instanceof Book);
	    }
	    @Test
	    public void testCreateItem_CD() {
	        LibraryItemFactory factory = new ConcreteLibraryItemFactory();
	        Item cd = factory.createItem("CD");
	        assertNotNull(cd);
	        assertTrue(cd instanceof CD);
	    }
	    @Test
	    public void testCreateItem_Magazine() {
	        LibraryItemFactory factory = new ConcreteLibraryItemFactory();
	        Item magazine = factory.createItem("Magazine");
	        assertNotNull(magazine);
	        assertTrue(magazine instanceof Magazine);
	    }
	    
	    /*
	     * Factory Test
	     */
	    @Test
	    public void testCreateItemCD() {
	        CDFactory factory = new CDFactory();
	        Item cd = factory.createItem("CD");
	        assertNotNull(cd);
	        assertTrue(cd instanceof CD);
	        assertEquals("CD", cd.getTitle());
	        assertEquals("CD", cd.getLocations());
	        assertFalse(cd.getAvailability());
	        assertEquals(0, cd.getItemId());
	    }
	    
	    @Test
	    public void testCreateItemNotCD() {
	        CDFactory factory = new CDFactory();
	        Item item = factory.createItem("Other");
	        assertNull(item);
	    }
	    @Test
	    public void testCreateItemMagazine() {
	        MagazineFactory factory = new MagazineFactory();
	        Item magazine = factory.createItem("Magazine");
	        assertNotNull(magazine);
	        assertTrue(magazine instanceof Magazine);
	        assertEquals("Magazine", magazine.getTitle());
	        assertEquals("Magazine", magazine.getLocations());
	        assertFalse(magazine.getAvailability());
	        assertEquals(0, magazine.getItemId());
	    }

	    @Test
	    public void testCreateItemNotMagazine() {
	        MagazineFactory factory = new MagazineFactory();
	        Item item = factory.createItem("Other");
	        assertNull(item);
	    }
	    
	    @Test
	    public void testCreateItemBook() {
	        BookFactory factory = new BookFactory();
	        Item book = factory.createItem("Book");
	        assertNotNull(book);
	        assertTrue(book instanceof Book);
	        assertEquals("Book", book.getTitle());
	        assertEquals("Book", book.getLocations());
	        assertFalse(book.getAvailability());
	        assertEquals(0, book.getItemId());
	    }

	    @Test
	    public void testCreateItemNotBook() {
	        BookFactory factory = new BookFactory();
	        Item item = factory.createItem("Other");
	        assertNull(item);
	    }
	    
	    /*
	     * Borrowing System Test
	     */
	    @Test
	    public void testSetAndGetOverduePenalty() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        float penalty = 0.5f;
	        
	        borrowingSystem.setOverduePenalty(penalty);
	        
	        assertEquals(penalty, borrowingSystem.getOverduePenalty(), 0.01);
	    }
	    
	    @Test
	    public void testBorrowingItem() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        Client client = new Client();
	        Item item = new Item(1, "Test Item", "Test Location", true);
	        borrowingSystem.borrowItem(client, item);
	
	        List<Item> clientBorrowedItems = borrowingSystem.getBorrowedItems(client);
	        assertNotNull(clientBorrowedItems);
	        assertTrue(clientBorrowedItems.contains(item));
	        assertEquals(1, clientBorrowedItems.size());
	        
	        Date currentDate = new Date();
	        assertEquals(currentDate, item.getBorrowDates());
	    }
	    @Test
	    public void testReturningItem() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        Client client = new Client();
	        Item item = new Item(1, "Test Item", "Test Location", true);
	        
	        borrowingSystem.borrowItem(client, item);
	        borrowingSystem.returnItem(client, item);
	        
	        List<Item> clientBorrowedItems = borrowingSystem.getBorrowedItems(client);
	        assertNotNull(clientBorrowedItems);
	        assertFalse(clientBorrowedItems.contains(item));
	    }
	    @Test
	    public void testGetOverdueItems() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        Client client = new Client();
	        
	        List<Item> overdueItems = borrowingSystem.getOverdueItems(client);
	        
	        assertNotNull(overdueItems);
	        assertTrue(overdueItems.isEmpty());
	    }
	    

	    @Test
	    public void testApplyingPenalty() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        Client client = new Client();
	        Item item = new Item(1, "Test Item", "Test Location", true);
	        Date borrowDate = new Date();
	        item.setBorrowDate(borrowDate);

	        borrowingSystem.applyPenalty(client, item);
	        
	        List<Item> overdueItems = borrowingSystem.getOverdueItems(client);
	        
	        assertNotNull(overdueItems);
	        
	        //assertTrue(overdueItems.contains(item));	    
	    }
	    @Test
	    public void testGetDueDate() {
	        BorrowingSystem borrowingSystem = new BorrowingSystem();
	        Client client = new Client();
	        Item item = new Item(1, "Test Item", "Test Location", true);
	        borrowingSystem.borrowItem(client, item);

	        Date dueDate = borrowingSystem.getDueDate(item);
	        
	        assertNotNull(dueDate);
	        String formattedDueDate = item.getFormattedDueDate();
	        assertNotNull(formattedDueDate);
	        SimpleDateFormat dateFormat = new SimpleDateFormat("E, MMM dd, yyyy");
	        dateFormat.format(dueDate);
	        
	    }
	    
	    /*
	     * Course Textbook Manager Test
	     */
	    @Test
	    public void testAssignCourse() {
	        CourseTextbookManager manager = new CourseTextbookManager();
	        Student student = new Student(1, "student@example.com", "password");
	        String assignedCourse = manager.assignCourse(student);
	        assertNotNull(assignedCourse);
	        Faculty faculty = new Faculty(2, "faculty@example.com", "password","faculty");
	        assignedCourse = manager.assignCourse(faculty);
	        assertNotNull(assignedCourse);
	    }
	    @Test
	    public void testGetTextbookForCourse() {
	        CourseTextbookManager manager = new CourseTextbookManager();
	        Map<String, String> coursesWithEditions = manager.getCoursesWithEditions();
	        for (Map.Entry<String, String> entry : coursesWithEditions.entrySet()) {
	            String course = entry.getKey();
	            String expectedTextbook = entry.getValue();
	            String actualTextbook = manager.getTextbookForCourse(course);
	            assertEquals(expectedTextbook, actualTextbook);
	        }
	    }
	    
	    /*
	     * Client Manager Test
	     */
	    @Test
	    public void testGetAvailableNewsletters() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        List<String> availableNewsletters = clientManager.getAvailableNewsletters();
	        assertNotNull(availableNewsletters);
	        assertFalse(availableNewsletters.isEmpty());
	        assertEquals(3, availableNewsletters.size());
	        assertTrue(availableNewsletters.contains("NY Times"));
	        assertTrue(availableNewsletters.contains("National Geographic"));
	        assertTrue(availableNewsletters.contains("Tech Crunch"));
	    }
	    @Test
	    public void testSubscribeNewsletter() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        Client client = new Client();
	        String newsletter = "NY Times";
	        clientManager.subscribeNewsletter(client, newsletter);
	        assertTrue(clientManager.getSubscribedNewsletters().contains(newsletter));
	    }
	    
	    @Test
	    public void testCancelSubscription() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        clientManager.subscribeNewsletter(new Client(), "NY Times");
	        clientManager.subscribeNewsletter(new Client(), "National Geographic");
	        clientManager.subscribeNewsletter(new Client(), "Tech Crunch");

	        int initialSize = clientManager.getSubscribedNewsletters().size();
	        clientManager.cancelSubscription(new Client(), "National Geographic");
	        
	        assertFalse(clientManager.getSubscribedNewsletters().contains("National Geographic"));
	        assertEquals(initialSize - 1, clientManager.getSubscribedNewsletters().size());
	    }
	    @Test
	    public void testCreateClientWithExistingEmail() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        Client existingClient = new Client(1, "test@example.com", "password","Faculty");
	        clientManager.getClients().add(existingClient);

	        boolean result = clientManager.registerUser("test@example.com", "newpassword", "Student");

	        assertFalse(result);
	    }
	    
	    @Test
	    public void testIsEmailRegistered() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        assertFalse(clientManager.isEmailRegistered("test@example.com"));
	        clientManager.getClients().add(new Client(0, "test@example.com", "password","Student"));
	        assertTrue(clientManager.isEmailRegistered("test@example.com"));
	    }

	    @Test
	    public void testLoginUser() throws IOException {
	        ClientManager clientManager = new ClientManager();
	        assertFalse(clientManager.loginUser("test@example.com", "password"));
	        clientManager.getClients().add(new Client(0, "test@example.com", "password","Faculty"));
	        assertFalse(clientManager.loginUser("test@example.com", "wrongpassword"));
	        assertFalse(clientManager.loginUser("nonexistent@example.com", "password"));
	    }
	    
	    /*
	     * CSV Reader
	     */
	    @Test
	    public void testReadData() throws IOException {
	        String filePath = "test.csv";
	        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
	        writer.write("1,J,Doe\n");
	        writer.write("2,Jane,D\n");
	        writer.close();

	        CSVReader csvReader = new CSVReader(filePath);
	        List<String[]> dataList = csvReader.readData();

	        assertNotNull(dataList);
	        assertEquals(2, dataList.size());
	        assertArrayEquals(new String[]{"1", "J", "Doe"}, dataList.get(0));
	        assertArrayEquals(new String[]{"2", "Jane", "D"}, dataList.get(1));	        
	    }
	    @Test
	    public void testReadDataWithEmptyFile() throws IOException {
	        String filePath = "empty.csv";
	        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
	        writer.close();

	        CSVReader csvReader = new CSVReader(filePath);
	        List<String[]> dataList = csvReader.readData();

	        assertNotNull(dataList);
	        assertTrue(dataList.isEmpty());

	        File file = new File(filePath);
	        assertTrue(file.delete());
	    }
	    
	    /*
	     * CSV Writer Test
	     */
	    @Test
	    public void testWriteData() throws IOException {
	        String filePath = "test.csv";
	        CSVWriter csvWriter = new CSVWriter(filePath);
	        List<String[]> rows = new ArrayList<>();
	        rows.add(new String[]{"Email", "Password", "Type"});
	        rows.add(new String[]{"user1@example.com", "password1", "Admin"});
	        rows.add(new String[]{"user2@example.com", "password2", "User"});

	        csvWriter.writeData(rows);

	        BufferedReader reader = new BufferedReader(new FileReader(filePath));
	        reader.close();

	        File file = new File(filePath);
	        assertTrue(file.delete());
	    }

	    @Test
	    public void testWriteDataWithSections() throws IOException {
	        String filePath = "test_sections.csv";
	        CSVWriter csvWriter = new CSVWriter(filePath);
	        List<List<String[]>> sections = new ArrayList<>();
	        List<String[]> section1 = new ArrayList<>();
	        section1.add(new String[]{"Item Type", "Item ID ", "Title", "Location", "Available"});
	        section1.add(new String[]{"Book", "1", "Book Title", "Library", "true"});
	        section1.add(new String[]{"CD", "2", "CD Title", "Music Store", "false"});
	        sections.add(section1);

	        csvWriter.writeData1(sections);

	        BufferedReader reader = new BufferedReader(new FileReader(filePath));
	        String firstLine = reader.readLine();
	        if (firstLine.equals("Item Type,Item ID,Title,Location,Available")) {
	            reader.readLine();
	        }

	        reader.close();

	        File file = new File(filePath);
	        assertTrue(file.delete());
	    }
	    
	    @Before
	    public void setUp() throws IOException {
	        csvWriter = new CSVWriter("test_database.csv"); // Use actual CSVWriter object
	        clientManager = new ClientManager();
	    }
	    @Test
	    public void testRegisterUser_EmailAlreadyRegistered() {

	      
	    }

	    @Test
	    public void testRegisterUser_SuccessfulRegistration() throws IOException {
	    }

	    @Test
	    public void testRegisterUser_CSVWriteIOException() throws IOException {
	        String email = "newuser@example.com";
	        String password = "password";
	        String type = "user";

	        new CSVWriter("nonexistent_directory/test.csv");
	        ClientManager clientManagerWithFaultyWriter = new ClientManager();

	        clientManagerWithFaultyWriter.registerUser(email, password, type);
	    }

	  
	
	

}
