package NonGUIClasses;

public class CD extends Item{
	// Constructor
    public CD(int itemId, String title, String location, boolean available) {
    	super(itemId, title, location, available);
    }
    
    public CD() {
    	
    }

}
