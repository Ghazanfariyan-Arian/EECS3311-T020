package NonGUIClasses;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JPanel;

public class Item {
	private static final long serialVersionUID = 1L;
	private int itemId;
	private String title;
	private String locations;
	private boolean available;
	private Date borrowDate;
	private String formattedDueDate;
	
	 // Constructor
    public Item(int itemId, String title, String locations, boolean available) {
        this.itemId = itemId;
        this.title = title;
        this.locations = locations;
        this.available = available;
    }
	
	public void setItemId(int id) {
        this.itemId = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setLocation(String locations) {
        this.locations = locations;
    }

    public void setAvailability(boolean available) {
        this.available = available;
    }

    public int getItemId() {
        return itemId;
    }
    public String getTitle() {
        return title;
    }
    public String getLocations() {
    	return locations;
    }
    public boolean getAvailability() {
        return available;
    }
   
    public String getItemDetails() {
        return "Item ID: " + itemId + "\nTitle: " + title + "\nLocation: " + locations + "\nAvailable: " + (available ? "Yes" : "No");
    }
    

    public void borrowItem(Client client) {
        if (available) {
            System.out.println(client.getId() + " has borrowed the item: " + title);
            available = false;
        }
    }

    public void returnItem(Client client) {
        System.out.println(client.getId() + " has returned the item: " + title);
        available = true;
    }
    
    @Override
    public String toString() {
        return "ID: " + itemId + ", Title: " + title + ", Location: " + locations + ", Available: " + available;
    }

	public void setBorrowDate(Date borrowDate) {
        this.borrowDate = borrowDate;

	}
	public Date getBorrowDates() {
         return borrowDate;

	}
	public void setFormattedDueDate(Date borrowDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(borrowDate);
        calendar.add(Calendar.DAY_OF_MONTH, 30);
        Date dueDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("E, MMM dd, yyyy");
        this.formattedDueDate = dateFormat.format(dueDate);
    }
	
	public String getFormattedDueDate() {
		return this.formattedDueDate;
	}

	public String getBorrowDate() {
		 SimpleDateFormat dateFormat = new SimpleDateFormat("E, MMM dd, yyyy");
	     return dateFormat.format(borrowDate);

	}

}
