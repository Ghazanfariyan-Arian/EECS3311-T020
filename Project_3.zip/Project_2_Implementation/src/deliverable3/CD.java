package deliverable3;

import deliverable3.Item;

public class CD extends Item{
	// Constructor
    public CD(int itemId, String title, String location, boolean available) {
    	super(itemId, title, location, available);
    }
    
    public CD() {
    	
    }

}
