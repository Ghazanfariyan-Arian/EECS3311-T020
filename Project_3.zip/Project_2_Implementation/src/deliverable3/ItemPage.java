package NonGUIClasses;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Font;


public class ItemPage extends JFrame {
	private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> comboBoxType;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ItemPage frame = new ItemPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ItemPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 JLabel lblSelectItem = new JLabel("Select Item:");
	     lblSelectItem.setBounds(23, 29, 109, 25);
	     lblSelectItem.setFont(new Font("Yu Gothic", Font.PLAIN, 17));
	     contentPane.add(lblSelectItem);
		
		// Options on what to borrow
		JComboBox comboBoxType = new JComboBox();
	    comboBoxType.setFont(new Font("Yu Gothic", Font.PLAIN, 15));
	    comboBoxType.setBounds(23, 52, 133, 31);
	    contentPane.add(comboBoxType);
	    
	        comboBoxType.addItem("Book");
	        comboBoxType.addItem("Magazine");
	        comboBoxType.addItem("CD");
	        
	    JButton btnReturn = new JButton("Return");
	    btnReturn.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 20));
	    btnReturn.setBounds(220, 175, 138, 41);
	    contentPane.add(btnReturn);
	  
		
		JButton btnBorrow = new JButton("Borrow");
		btnBorrow.setFont(new Font("Yu Gothic UI Light", Font.PLAIN, 20));
		btnBorrow.setBounds(220, 108, 138, 41);
		contentPane.add(btnBorrow);

		btnBorrow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String selectedItemType = (String) comboBoxType.getSelectedItem();
				if ("Book".equals(selectedItemType)) {
					BorrowPage borrowBook = new BorrowPage();
			        borrowBook.setVisible(true);
	                }
	            }
		});
		setVisible(true);
		
		
		
	}
	
	 

		
	
}

















