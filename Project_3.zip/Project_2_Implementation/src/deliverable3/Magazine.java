package deliverable3;

import deliverable3.Item;

public class Magazine extends Item {
	// Constructor
    public Magazine(int itemId, String title, String location, boolean available) {
    	super(itemId, title, location, available);
    }
    
    public Magazine() {
    	
    }

}
