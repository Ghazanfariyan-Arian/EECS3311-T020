package deliverable3;

import deliverable3.Item;

public abstract class LibraryItemFactory {
	public abstract Item createItem(String itemType);

}
