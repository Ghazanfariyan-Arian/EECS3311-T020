package deliverable3;

import static org.junit.Assert.*;

import org.junit.Test;

import NonGUIClasses.Client;

import static org.junit.Assert.assertEquals;

public class JunitTestCases {

	 @Test
	    public void testConstructorClient() {
	        Client client = new Client(1, "test@example.com", "testpassword", "Student");
	        assertEquals(1, client.getId());
	        assertEquals("test@example.com", client.getEmail());
	        assertEquals("testpassword", client.getPassword());
	        assertEquals("Student", client.getType());
	       
	        
	        // Default constructor test
	        Client defaultClient = new Client();
	        assertEquals(0, defaultClient.getId());
	        assertEquals("default@example.com", defaultClient.getEmail());
	        assertEquals("password", defaultClient.getPassword());
	        assertEquals("Student", defaultClient.getType());
	        assertNotNull(defaultClient.getCourses());
	    }

}







	
