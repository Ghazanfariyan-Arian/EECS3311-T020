package deliverable3;

import deliverable3.Item;
import deliverable3.LibraryItemFactory;

public class MagazineFactory extends LibraryItemFactory {
	@Override
	public Item createItem(String itemType) {
		if (itemType.equalsIgnoreCase("Magazine")) {
            return new Magazine(0, itemType, itemType, false);
        } else {
        	return null;
        }
	}

}
